Project orflib
===============
Michael G Sotiropoulos, 1-Sep-2024

This repository contains the source code for the `orflib` quant library and its interfaces.
